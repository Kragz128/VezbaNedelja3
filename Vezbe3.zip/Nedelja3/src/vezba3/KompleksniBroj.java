package vezba3;
import java.util.Scanner;

public class KompleksniBroj {
	
	private double realniDeo;
	private double imaginarniDeo;
	
	public KompleksniBroj() {
		this.realniDeo = 0;
		this.imaginarniDeo = 0;
	}
	
	public KompleksniBroj(double realniDeo, double imaginarniDeo) {
		this.realniDeo = realniDeo;
		this.imaginarniDeo = imaginarniDeo;
	}
	public double getRealniDeo() {
		return realniDeo;
	}
	public double getImaginarniDeo() {
		return imaginarniDeo;
	}
	public void setRealniDeo(double realniDeo) {
		this.realniDeo = realniDeo;
	}
	public void setImaginarniDeo(double imaginarniDeo) {
		this.imaginarniDeo = imaginarniDeo;
	}
	public String toString() {
		return realniDeo + " + " + imaginarniDeo + "i";
	}
	public float modulBroja() {
		return (float) Math.sqrt(realniDeo * realniDeo + imaginarniDeo * imaginarniDeo);
	}
	public KompleksniBroj saberi(KompleksniBroj k) {
		return new KompleksniBroj(this.realniDeo + k.realniDeo, this.imaginarniDeo + k.imaginarniDeo);
	}
	public KompleksniBroj oduzmi(KompleksniBroj k) {
		return new KompleksniBroj(this.realniDeo - k.realniDeo, this.imaginarniDeo - k.imaginarniDeo);
	}
	public KompleksniBroj pomnozi(KompleksniBroj k) {
		return new KompleksniBroj(this.realniDeo * k.realniDeo - this.imaginarniDeo * k.imaginarniDeo,
				this.realniDeo * k.imaginarniDeo + this.imaginarniDeo * k.realniDeo);
	}
	public KompleksniBroj podeli(KompleksniBroj k) {
		double imenilac = k.realniDeo * k.realniDeo + k.imaginarniDeo * k.imaginarniDeo;
		return new KompleksniBroj((this.realniDeo * k.realniDeo + this.imaginarniDeo * k.imaginarniDeo) / imenilac,
				(this.imaginarniDeo * k.realniDeo - this.realniDeo * k.imaginarniDeo) / imenilac);
	}
}
