package vezba3;
import java.util.Scanner;

public class KompleksniBrojTest {

	public static void main(String[] args) {
		float realniDeo1, imaginarniDeo1, realniDeo2, imaginarniDeo2;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Unesite realni deo prvog kompleksnog broja: ");
		realniDeo1 = sc.nextFloat();
		System.out.print("Unesite imaginarni deo prvog kompleksnog broja: ");
		imaginarniDeo1 = sc.nextFloat();
		
		System.out.print("Unesite realni deo drugog kompleksnog broja: ");
		realniDeo2 = sc.nextFloat();
		System.out.print("Unesite imaginarni deo drugog kompleksnog broja: ");
		imaginarniDeo2 = sc.nextFloat();
		
		KompleksniBroj k1 = new KompleksniBroj(realniDeo1, imaginarniDeo1);
		KompleksniBroj k2 = new KompleksniBroj(realniDeo2, imaginarniDeo2);
		
		KompleksniBroj rezultatSabiranja = k1.saberi(k2);
		KompleksniBroj rezultatOduzimanja = k1.oduzmi(k2);
		KompleksniBroj rezultatMnozenja = k1.pomnozi(k2);
		KompleksniBroj rezultatDeljenja = k1.podeli(k2);
		
		System.out.println("Rezultat sabiranja: " + rezultatSabiranja);
		System.out.println("Rezultat oduzimanja: " + rezultatOduzimanja);
		System.out.println("Rezultat mnozenja: " + rezultatMnozenja);
		System.out.println("Rezultat deljenja: " + rezultatDeljenja);
		System.out.println("Modul prvog kompleksnog broja: " + k1.modulBroja());
		System.out.println("Modul drugog kompleksnog broja: " + k2.modulBroja());
		System.out.print("Unesite broj kompleksnih brojeva: ");
		int N = sc.nextInt();
		
		KompleksniBroj niz[] = new KompleksniBroj[N];
		for (int i = 0; i < N; i++) {
			System.out.println("Unesite elemente kompleksnog broja " + (i + 1) + ":");
			niz[i] = new KompleksniBroj(sc.nextDouble(), sc.nextDouble());
		}
		KompleksniBroj max;
		max = niz[0];
		for (int i = 1; i < N; i++) {
			if (niz[i].modulBroja() > max.modulBroja()) {
				max = niz[i];
			}
		}
		System.out.print("Kompleksni broj sa najvećim modulom je: " + max);
	}

}
